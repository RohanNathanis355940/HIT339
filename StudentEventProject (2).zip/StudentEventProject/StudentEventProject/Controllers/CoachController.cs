﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StudentEventProject.Data;
using StudentEventProject.Models;

namespace StudentEventProject.Controllers
{
    public class CoachController : Controller
    {
        private readonly Hitdb1Context _context;

        public CoachController(Hitdb1Context context)
        {
            _context = context;
        }

        // GET: Coach
        public async Task<IActionResult> Index()
        {
            
            var coachList = await _context.Coaches.ToListAsync();
            List<CoachViewModel> lstCoaches=new List<CoachViewModel>();
            foreach (var item in coachList)
            {
                CoachViewModel coach = new CoachViewModel();
                coach.CoachId = item.CoachId;
                coach.FirstName = item.FirstName;
                coach.LastName=item.LastName;
                coach.Biography = item.Biography;
                
               if ( item.Photo.Length>0)
                {
                    var image = item.Photo;
                    string mimeType = GetMimeType(item.Photo);
                    coach.Photo = $"data:{mimeType};base64,{Convert.ToBase64String(image)}";
                }
                lstCoaches.Add(coach);
            }
           
            return View(lstCoaches);
        }
        private string GetMimeType(byte[] imageData)
        {
            if (imageData.Length > 4)
            {
                // Check if the image is a JPEG
                if (imageData[0] == 0xFF && imageData[1] == 0xD8)
                {
                    return "image/jpeg";
                }
                // Check if the image is a PNG
                else if (imageData[0] == 0x89 && imageData[1] == 0x50 && imageData[2] == 0x4E && imageData[3] == 0x47)
                {
                    return "image/png";
                }
                // Add more checks for other image types if needed
            }

            return "application/octet-stream"; // Default MIME type if unknown
        }
        // GET: Coach/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var coach = await _context.Coaches
                .FirstOrDefaultAsync(m => m.CoachId == id);
            if (coach == null)
            {
                return NotFound();
            }

            return View(coach);
        }

        // GET: Coach/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Coach/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Coach coach, IFormFile Image)
        {
            ModelState.Remove("CoachId");
            if (ModelState.IsValid)
            {
                try
                {


                    // Handle the image upload
                    if (Image != null && Image.Length > 0)
                    {
                        using (var memoryStream = new MemoryStream())
                        {
                            await Image.CopyToAsync(memoryStream);
                            coach.Photo = memoryStream.ToArray(); // Convert image to byte[]

                        }
                    }

                    _context.Add(coach);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }

                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Error adding item: {ex.Message}");
                    ModelState.AddModelError("", "An error occurred while adding the item. Please try again.");
                }
            }

            else
            {
                // Log validation errors
                foreach (var key in ModelState.Keys)
                {
                    var state = ModelState[key];
                    if (state.Errors.Any())
                    {
                        System.Diagnostics.Debug.WriteLine($"Key: {key}, Errors: {string.Join(", ", state.Errors.Select(e => e.ErrorMessage))}");
                    }
                }
            }
            return View(coach);
        }

        // GET: Coach/Edit/5
        public async Task<IActionResult> Edit(int? Id)
        {
            if (Id == null)
            {
                return NotFound();
            }
            CoachViewModel model = new CoachViewModel();
            var coach = await _context.Coaches.FindAsync(Id);
            if (coach != null)
            {
                model.FirstName = coach.FirstName;
                model.LastName = coach.LastName;
                model.Biography = coach.Biography;
                model.CoachId= coach.CoachId;
                if (coach.Photo != null)
                {
                    var image = coach.Photo;
                    string mimeType = GetMimeType(coach.Photo);
                    model.Photo = $"data:{mimeType};base64,{Convert.ToBase64String(image)}";
                }
            }
            if (coach == null)
            {
                return NotFound();
            }
            return View(model);
        }

        // POST: Coach/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit( CoachViewModel coach, IFormFile Image)
        {
           

            if (ModelState.IsValid)
            {
                try
                {
                    var coachObj = await _context.Coaches.FindAsync(coach.CoachId);

                    if (coachObj != null)
                    {
                        if (Image != null && Image.Length > 0)
                        {
                            using (var memoryStream = new MemoryStream())
                            {
                                await Image.CopyToAsync(memoryStream);
                                coachObj.Photo = memoryStream.ToArray(); // Convert image to byte[]

                            }
                        }
                        coachObj.FirstName = coach.FirstName;
                        coachObj.LastName = coach.LastName;
                        coachObj.Biography= coach.Biography;
                        _context.Update(coachObj);
                        await _context.SaveChangesAsync();
                    }
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CoachExists(coach.CoachId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(coach);
        }

        // GET: Coach/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var coach = await _context.Coaches
                .FirstOrDefaultAsync(m => m.CoachId == id);
            if (coach == null)
            {
                return NotFound();
            }

            return View(coach);
        }

        // POST: Coach/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var coach = await _context.Coaches.FindAsync(id);
            if (coach != null)
            {
                _context.Coaches.Remove(coach);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CoachExists(int id)
        {
            return _context.Coaches.Any(e => e.CoachId == id);
        }
    }
}
