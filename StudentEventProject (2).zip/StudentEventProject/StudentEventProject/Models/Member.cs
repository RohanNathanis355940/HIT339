﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace StudentEventProject.Models;

public partial class Member
{
    public int MemberId { get; set; }

    [Display(Name ="First Name")]
    public string? FirstName { get; set; }
    [Display(Name = "Last Name")]
    public string LastName { get; set; } = null!;

    public string? Email { get; set; }

    public bool Active { get; set; }
}
