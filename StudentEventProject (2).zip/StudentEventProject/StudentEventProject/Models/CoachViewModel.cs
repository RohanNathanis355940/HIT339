﻿using System.ComponentModel.DataAnnotations;

namespace StudentEventProject.Models
{
    public class CoachViewModel
    {
        public int CoachId { get; set; }
        [Display(Name = "First Name")]
        public string FirstName { get; set; } = null!;
        [Display(Name = "Last Name")]
        public string LastName { get; set; } = null!;

        public string? Biography { get; set; }

        public string Photo { get; set; } = null!;
    }
}
